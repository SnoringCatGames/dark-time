# Dark Time

_[Check it out on the Chrome Web Store!](https://chrome.google.com/webstore/detail/dark-time/ofmngaeacndglijmheklbcnbjfdcohke)_

A Chrome extension that replaces the new tab page.

Shows the current time, with configurable settings (analog vs digital, time format, tab text, background and text colors).
