# Dark Time

A Chrome extension that replaces the new tab page.

Shows the current time, with configurable background and text colors.
